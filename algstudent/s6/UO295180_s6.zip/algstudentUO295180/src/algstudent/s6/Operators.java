package algstudent.s6;

public enum Operators {
	ADD, SUB, DIV, MUL
}
