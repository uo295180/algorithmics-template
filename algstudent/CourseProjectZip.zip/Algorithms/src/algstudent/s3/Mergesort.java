package algstudent.s3;

import algstudent.s2.Vector;

public class Mergesort {
	
	static int []v;
	
	public static void mergesort(int[]arr){
		mergesort(arr,0,arr.length-1);
	}
	private static void mergesort(int[] elements, int left, int right)
	{
		if (right>left) {
			int center = (left+right)/2;
			mergesort(elements, left, center);
			mergesort(elements, center+1, right);
			combine(elements, left, center, center+1, right);
		}
	}
	
	private static void combine(int[] elements, int x1, int x2, int y1, int y2) {
		int sizeX = x2-x1+1;
		int sizeY = y2-y1+1;
		
		int[] x = new int[sizeX];
		int[] y = new int[sizeY];
		
		for(int i = 0; i < sizeX; i++) {
			x[i] = elements[x1+i];
		}
		for(int i = 0; i < sizeY; i++) {
			y[i] = elements[y1+i];
		}
		
		int i = 0; 
		int j = 0;
		int k = x1;
		
		while(i < sizeX && j < sizeY) {
			if(x[i] <= y[j]) {
				elements[k] = x[i];
				i++;
			} else {
				elements[k] = y[j];
				j++;
			}
			k++;
		}
		
		while(i < sizeX) {
			elements[k] = x[i];
			i++;
			k++;
		}
		
		while(j < sizeY) {
			elements[k] = y[j];
			j++;
			k++;
		}
	}
	
	public static void main(String arg[]) {
		int n = Integer.parseInt(arg[0]); //size of the problem
		v = new int[n];

		Vector.sorted(v);
		System.out.println("VECTOR TO BE SORTED");
		Vector.print(v);
		mergesort(v);
		System.out.println("SORTED VECTOR");
		Vector.print(v);

		Vector.reverseSorted(v);
		System.out.println("VECTOR TO BE SORTED");
		Vector.print(v);
		mergesort(v);
		System.out.println("SORTED VECTOR");
		Vector.print(v);

		Vector.randomSorted(v);
		System.out.println("VECTOR TO BE SORTED");
		Vector.print(v);
		mergesort(v);
		System.out.println("SORTED VECTOR");
		Vector.print(v);
	} 
	

}
